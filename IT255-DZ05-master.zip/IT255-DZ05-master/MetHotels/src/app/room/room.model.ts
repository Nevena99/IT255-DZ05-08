export class RoomModel {
    tip: string;
    cena: number;
    brojnoci: number;
    constructor(tip: string, cena: number, brojnoci: number) {
        this.tip = tip;
        this.cena = cena;
        this.brojnoci = brojnoci;
    }
}

